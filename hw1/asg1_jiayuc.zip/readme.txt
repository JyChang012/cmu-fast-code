1. `$ make` to compile and run latencies, throughput and kernel (throughput src will be generated)
2. `$ . run.sh` and `$ . run_fma.sh` to rerun throughput test after generation and compilation