1. `$ make` to compile all
2. `$ make run` to run all. Addtional result would be printed out.