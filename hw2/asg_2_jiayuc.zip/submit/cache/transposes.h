
void morton(double *a, double *b, int N);

