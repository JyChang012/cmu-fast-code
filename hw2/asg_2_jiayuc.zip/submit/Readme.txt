# Run z-ordering transpose
1. cd to `cache` and run `make` to compile.
2. run `./transpose.x 1000 4 512` to execute

# Run pack and matmul
1. cd to `mmm` and run `make` to compile
2. run `./mmm.x` to execute